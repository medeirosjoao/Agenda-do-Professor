(function(window, undefined) {

  var jimLinks = {
    "25d126a0-acd7-44ac-80a3-74833e6bbf59" : {
      "Paragraph_8" : [
        "16864509-85f0-40bc-8efb-f99bba0f021f"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "8e663f7c-7e1d-430e-a531-c3d3c8975e2d" : {
      "Text_4" : [
        "17f07bac-4cdb-48b0-a4b1-949b42f98273"
      ],
      "Text_2" : [
        "8e663f7c-7e1d-430e-a531-c3d3c8975e2d"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "8a8e41b7-17cc-400e-a202-8a17867f98c8" : {
      "Paragraph_7" : [
        "bbfdd63a-c28e-41a8-bddc-8b1fad1b98f7"
      ]
    },
    "bbfdd63a-c28e-41a8-bddc-8b1fad1b98f7" : {
      "Paragraph_8" : [
        "16864509-85f0-40bc-8efb-f99bba0f021f"
      ],
      "Button_1" : [
        "8a8e41b7-17cc-400e-a202-8a17867f98c8"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Paragraph_10" : [
        "8e663f7c-7e1d-430e-a531-c3d3c8975e2d"
      ],
      "Paragraph_9" : [
        "8e663f7c-7e1d-430e-a531-c3d3c8975e2d"
      ],
      "Text_4" : [
        "17f07bac-4cdb-48b0-a4b1-949b42f98273"
      ],
      "Text_2" : [
        "8e663f7c-7e1d-430e-a531-c3d3c8975e2d"
      ]
    },
    "17f07bac-4cdb-48b0-a4b1-949b42f98273" : {
      "Text_4" : [
        "17f07bac-4cdb-48b0-a4b1-949b42f98273"
      ],
      "Text_2" : [
        "8e663f7c-7e1d-430e-a531-c3d3c8975e2d"
      ],
      "Text_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);