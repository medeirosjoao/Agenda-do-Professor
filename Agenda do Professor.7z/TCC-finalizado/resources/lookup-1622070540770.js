(function(window, undefined) {
  var dictionary = {
    "25d126a0-acd7-44ac-80a3-74833e6bbf59": "Professor",
    "8e663f7c-7e1d-430e-a531-c3d3c8975e2d": "Biblioteca do Professor",
    "16864509-85f0-40bc-8efb-f99bba0f021f": "Sobre",
    "8a8e41b7-17cc-400e-a202-8a17867f98c8": "Biblioteca do Aluno",
    "bbfdd63a-c28e-41a8-bddc-8b1fad1b98f7": "Aluno",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Início",
    "17f07bac-4cdb-48b0-a4b1-949b42f98273": "Conteudo Programático",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);