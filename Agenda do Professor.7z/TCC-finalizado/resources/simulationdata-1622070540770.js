function initData() {
  jimData.variables["addConteudo"] = "";
  jimData.variables["tag"] = "";
  jimData.variables["vemdeoutra"] = "0";
  jimData.variables["variavel"] = "";
  jimData.variables["comentario"] = "";
  jimData.variables["turma"] = "";
  jimData.variables["datatest"] = "";
  jimData.variables["autor"] = "";
  jimData.isInitialized = true;
}