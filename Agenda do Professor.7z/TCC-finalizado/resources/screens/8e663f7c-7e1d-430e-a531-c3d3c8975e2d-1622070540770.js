jQuery("#simulation")
  .on("click", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_12" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeInBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_40")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_7" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Image_42","#s-Image_45","#s-Group_13" ],
                    "effect": {
                      "type": "slide",
                      "duration": 500,
                      "direction": "down"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_79")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_42","#s-Image_45","#s-Group_13" ],
                    "effect": {
                      "type": "slide",
                      "duration": 500,
                      "direction": "down"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_7" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_24")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_20" ],
                    "effect": {
                      "type": "fade",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_22")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_4" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_14" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeInBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_12" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeOutBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Paragraph_3" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeInBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 3000
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Paragraph_3" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeOutBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#D9D9D9"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_40")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#D9D9D9"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_42")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#D9D9D9"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_44")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#D9D9D9"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_46")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_46 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#D9D9D9"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_19 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_42 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_44 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_40 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/17f07bac-4cdb-48b0-a4b1-949b42f98273",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/8e663f7c-7e1d-430e-a531-c3d3c8975e2d",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_20")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_14" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeOutBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_18" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Paragraph_9",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_17" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_3",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_19" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_5",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Rectangle_24" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_6",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Group_20" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_14" ],
                    "effect": {
                      "type": "fade",
                      "easing": "easeOutBack",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_19")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Group_4" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mousedown", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .mousedown", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Text_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Text_2 > .backgroundLayer > .colorLayer": {
                      "attributes": {
                        "background-color": "#DDDDDD"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("drag", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .drag", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Image_45")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_45" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "592.0"
                    },
                    "left": {
                      "type": "movewithcursor",
                      "value": ""
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_42")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Image_42" ],
                    "top": {
                      "type": "movetoposition",
                      "value": "592.0"
                    },
                    "left": {
                      "type": "movewithcursor",
                      "value": ""
                    },
                    "containment": false
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("dragend", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .drag", function(event, data) {
    jimEvent(event).jimRestoreDrag(jQuery(this));
  })
  .on("dragend", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .drag", function(event, data) {
    if(data.drag.id.startsWith("s-"))
      jimEvent(event).jimDestroyDrag(jQuery(this));
  })
  .on("pageload", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "variable",
                  "element": "vemdeoutra"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_13": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_13 > .borderLayer": {
                      "attributes": {
                        "border-top-style": "solid",
                        "border-top-color": "#F07D6E",
                        "border-right-style": "solid",
                        "border-right-color": "#F07D6E",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#F07D6E",
                        "border-left-style": "solid",
                        "border-left-color": "#F07D6E"
                      }
                    }
                  },{
                    "#s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d #s-Rectangle_13 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-style": "solid",
                        "border-top-color": "#F07D6E",
                        "border-right-style": "solid",
                        "border-right-color": "#F07D6E",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#F07D6E",
                        "border-left-style": "solid",
                        "border-left-color": "#F07D6E"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Rectangle_18" ],
                    "value": {
                      "datatype": "variable",
                      "element": "turma"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("change", ".s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d .change", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Paragraph_9" ],
                    "value": "Doc5.docx"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });