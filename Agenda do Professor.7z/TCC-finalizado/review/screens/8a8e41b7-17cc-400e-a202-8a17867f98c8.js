var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622070540770.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622070540770-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-8a8e41b7-17cc-400e-a202-8a17867f98c8" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Biblioteca do Aluno" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/8a8e41b7-17cc-400e-a202-8a17867f98c8-1622070540770.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/8a8e41b7-17cc-400e-a202-8a17867f98c8-1622070540770-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/8a8e41b7-17cc-400e-a202-8a17867f98c8-1622070540770-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Promo_2" class="group firer ie-background commentable non-processed" customid="video" datasizewidth="1024.0px" datasizeheight="450.0px" >\
        <div id="s-Bg" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="929.0px" datasizeheight="731.0px" datasizewidthpx="929.0000000000002" datasizeheightpx="730.9999999999999" dataX="350.0" dataY="67.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Play" class="pie image lockV firer ie-background commentable non-processed" customid="Play"   datasizewidth="83.0px" datasizeheight="83.0px" dataX="773.0" dataY="391.0" aspectRatio="1.0"   alt="image" systemName="./images/d89505a6-d5f8-4aee-8d83-98c4404534c0.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>play button</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs>\
            	        <polygon id="s-Play-path-1" points="1.70149254e-05 0.0166746269 56.9913224 0.0166746269 56.9913224 56.9999319 1.70149254e-05 56.9999319" fill="#CBCBCB" jimofill=" " />\
            	    </defs>\
            	    <g fill="none" fill-rule="evenodd" id="s-Play-Page-1" stroke="none" stroke-width="1">\
            	        <g id="s-Play-Components" transform="translate(-101.000000, -1355.000000)">\
            	            <g id="s-Play-play-button" transform="translate(101.000000, 1355.000000)">\
            	                <path d="M36.4362247,27.9682344 L25.1595027,20.2451678 C24.745559,19.9625254 24.1962181,19.9200611 23.7426108,20.1396865 C23.2853976,20.3576133 23,20.8002611 23,21.2787488 L23,36.7196165 C23,37.2031999 23.2853976,37.6441492 23.7426108,37.862076 C23.936061,37.9539687 24.1473598,38 24.3606418,38 C24.6390081,38 24.9209802,37.9166001 25.1595027,37.7513291 L36.4362247,30.0352266 C36.7922956,29.7882542 36.9999887,29.4069248 36.9999887,29.0016456 C37.0017915,28.5897419 36.7886898,28.2099412 36.4362247,27.9682344" fill="#CBCBCB" id="s-Play-Fill-1" style="fill:#CBCBCB !important;" />\
            	                <g id="s-Play-Group-5">\
            	                    <mask fill="white" id="s-Play-mask-2">\
            	                        <use xlink:href="#s-Play-path-1" style="fill:#CBCBCB !important;" />\
            	                    </mask>\
            	                    <g id="s-Play-Clip-4" />\
            	                    <path d="M46.9324558,46.9498961 C42.0083364,51.8735051 35.4609931,54.5848334 28.496614,54.5848334 C14.1184916,54.5848334 2.42107075,42.8892842 2.42107075,28.5133737 C2.42107075,14.1330394 14.1184916,2.43374687 28.496614,2.43374687 C42.8725245,2.43374687 54.5682439,14.1330394 54.5682439,28.5133737 C54.5692648,35.4782633 51.857426,42.0257767 46.9324558,46.9498961 M48.6461991,8.36208716 C43.2640379,2.98043642 36.1082409,0.0166065672 28.496614,0.0166065672 C12.7835006,0.0166065672 1.70149254e-05,12.8000901 1.70149254e-05,28.5133737 C1.70149254e-05,44.2208722 12.7835006,56.9999319 28.496614,56.9999319 C44.2087066,56.9999319 56.9913394,44.2208722 56.9913394,28.5133737 C56.9921901,20.900726 54.0285304,13.7442484 48.6461991,8.36208716" fill="#CBCBCB" id="s-Play-Fill-3" mask="url(#s-Play-mask-2)" style="fill:#CBCBCB !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_18" class="pie image firer click ie-background commentable non-processed" customid="fechar"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="1231.6" dataY="98.0"   alt="image" systemName="./images/043e9387-5f83-4333-a213-ac7df6897362.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>close-icon copy</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_18-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B2B2B2" id="s-Image_18-Components" transform="translate(-729.000000, -1389.000000)">\
            	            <g id="s-Image_18-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
            	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_18-Fill-1" style="fill:#CBCBCB !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="left" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Lista" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="350.5px" datasizeheight="733.0px" datasizewidthpx="350.464" datasizeheightpx="732.9999999999999" dataX="0.0" dataY="68.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_1_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_2" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="102.0px" datasizewidthpx="307.99999999999994" datasizeheightpx="102.0" dataX="21.0" dataY="129.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_2_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Image_26" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="257.0" dataY="152.0"   alt="image" systemName="./images/da679969-c98e-443b-ad9a-d737ef3114c1.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
                	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
                	    <title>Combined Shape</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_26-Page-1" stroke="none" stroke-width="1">\
                	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_26-Combined-Shape" style="fill:#CBCBCB !important;" />\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="186.0px" datasizeheight="45.0px" dataX="43.0" dataY="164.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_1_0">V&iacute;deo: Verbo TO BE</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_3" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="102.0px" datasizewidthpx="307.99999999999994" datasizeheightpx="101.99999999999997" dataX="21.0" dataY="231.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_3_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Image_27" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="257.0" dataY="254.0"   alt="image" systemName="./images/462a41c6-9b22-4a63-9e59-563827383ecc.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
                	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
                	    <title>Combined Shape</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_27-Page-1" stroke="none" stroke-width="1">\
                	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_27-Combined-Shape" style="fill:#CBCBCB !important;" />\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="186.0px" datasizeheight="45.0px" dataX="43.0" dataY="266.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_2_0">V&iacute;deo: Past Tense</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_4" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="102.0px" datasizewidthpx="307.99999999999994" datasizeheightpx="102.0" dataX="21.0" dataY="333.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_4_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Image_28" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="257.0" dataY="356.0"   alt="image" systemName="./images/2b781f35-eeff-40df-ac37-7315f878b748.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
                	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
                	    <title>Combined Shape</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_28-Page-1" stroke="none" stroke-width="1">\
                	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_28-Combined-Shape" style="fill:#CBCBCB !important;" />\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="186.0px" datasizeheight="45.0px" dataX="43.0" dataY="368.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_3_0">V&iacute;deo: Present Perfect</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_5" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="102.0px" datasizewidthpx="307.99999999999994" datasizeheightpx="102.0" dataX="21.0" dataY="435.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_5_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Image_29" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="257.0" dataY="458.0"   alt="image" systemName="./images/e7f6c80c-cee4-4409-a3c6-18d1d037ddfe.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
                	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
                	    <title>Combined Shape</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_29-Page-1" stroke="none" stroke-width="1">\
                	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_29-Combined-Shape" style="fill:#CBCBCB !important;" />\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="186.0px" datasizeheight="45.0px" dataX="43.0" dataY="470.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_4_0">V&iacute;deo: The proper use of intonation</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_6" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="102.0px" datasizewidthpx="307.99999999999994" datasizeheightpx="102.0" dataX="21.0" dataY="537.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_6_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Image_30" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="257.0" dataY="560.0"   alt="image" systemName="./images/c632b282-aa5a-4952-a7d2-afae0bd03be8.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
                	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
                	    <title>Combined Shape</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_30-Page-1" stroke="none" stroke-width="1">\
                	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_30-Combined-Shape" style="fill:#CBCBCB !important;" />\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_5" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="186.0px" datasizeheight="45.0px" dataX="43.0" dataY="572.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_5_0">V&iacute;deo: Idiomatic Expressions</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Rectangle_8" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle"   datasizewidth="308.0px" datasizeheight="102.0px" datasizewidthpx="307.99999999999994" datasizeheightpx="102.0" dataX="21.0" dataY="639.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Rectangle_8_0"></span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Image_31" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="257.0" dataY="662.0"   alt="image" systemName="./images/4496248f-bd76-483c-ace6-d5790eb5c0a2.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
                	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
                	    <title>Combined Shape</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_31-Page-1" stroke="none" stroke-width="1">\
                	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_31-Combined-Shape" style="fill:#CBCBCB !important;" />\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_6" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="186.0px" datasizeheight="45.0px" dataX="43.0" dataY="674.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_6_0">V&iacute;deo: Simple Present</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Search-input" class="group firer ie-background commentable non-processed" customid="Search-input" datasizewidth="347.0px" datasizeheight="46.0px" >\
          <div id="s-Input_search" class="pie text firer commentable non-processed" customid="Input_search"  datasizewidth="308.5px" datasizeheight="46.0px" dataX="21.0" dataY="79.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Procurar"/></div></div>  </div></div></div>\
\
          <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="297.0" dataY="91.0"   alt="image" systemName="./images/f5e66e91-86c5-47cb-a4c0-71252d49877e.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Icon</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
              	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
              	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Top bar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="top"   datasizewidth="1280.0px" datasizeheight="67.0px" datasizewidthpx="1279.9999999999998" datasizeheightpx="66.99999999999952" dataX="-0.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="titulo"   datasizewidth="225.6px" datasizeheight="21.0px" dataX="22.0" dataY="23.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0">Biblioteca de v&iacute;deos do aluno</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_7" class="pie richtext autofit firer click ie-background commentable non-processed" customid="sair"   datasizewidth="25.9px" datasizeheight="19.0px" dataX="1218.0" dataY="15.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">Sair</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="bottom video" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_9" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 6"   datasizewidth="929.0px" datasizeheight="89.1px" datasizewidthpx="929.0" datasizeheightpx="89.0611570247936" dataX="350.0" dataY="710.9" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_9_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_136" class="pie image firer ie-background commentable non-processed" customid="Image_136"   datasizewidth="36.9px" datasizeheight="36.9px" dataX="373.0" dataY="755.5"   alt="image" systemName="./images/b5cf3ae5-a4c2-4b6f-bcdd-b49db994c950.svg" overlay="#7D7D7D">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8 5v14l11-7z" fill="#7D7D7D" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="871.0px" datasizeheight="4.0px" datasizewidthpx="871.0" datasizeheightpx="4.0" dataX="383.5" dataY="738.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 2.0 L 871.0 2.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
        <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="81.4px" datasizeheight="19.0px" dataX="429.8" dataY="761.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">--:--:-- / --:--:--</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_43" class="pie image firer ie-background commentable non-processed" customid="Image_43"   datasizewidth="39.9px" datasizeheight="39.9px" dataX="1217.6" dataY="755.5"   alt="image" systemName="./images/af1775a2-ff2e-4f98-87b6-7714e4e8a0df.svg" overlay="#7D7D7D">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" fill="#7D7D7D" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;