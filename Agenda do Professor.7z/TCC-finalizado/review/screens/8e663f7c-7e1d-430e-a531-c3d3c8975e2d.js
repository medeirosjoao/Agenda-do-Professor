var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622070540770.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1622070540770-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Biblioteca do Professor" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/8e663f7c-7e1d-430e-a531-c3d3c8975e2d-1622070540770.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/8e663f7c-7e1d-430e-a531-c3d3c8975e2d-1622070540770-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/8e663f7c-7e1d-430e-a531-c3d3c8975e2d-1622070540770-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="right panel" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="640.0px" datasizeheight="733.0px" datasizewidthpx="640.0" datasizeheightpx="733.04" dataX="640.0" dataY="67.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button Salvar"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1194.0" dataY="675.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">Salvar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="String salvar"   datasizewidth="154.6px" datasizeheight="19.0px" dataX="1011.6" dataY="682.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">V&iacute;deo salvo na biblioteca</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Bg" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="605.0px" datasizeheight="476.5px" datasizewidthpx="605.0" datasizeheightpx="476.50551259074115" dataX="657.0" dataY="166.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_27" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="57.0px" datasizeheight="57.0px" dataX="931.0" dataY="371.5"   alt="image" systemName="./images/b0db5af8-bd0f-4b1e-9e32-c360324a0b75.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
            	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
            	    <title>Combined Shape</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_27-Page-1" stroke="none" stroke-width="1">\
            	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_27-Combined-Shape" style="fill:#CBCBCB !important;" />\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_13" class="group firer ie-background commentable hidden non-processed" customid="bottom video cut" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_16" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 6"   datasizewidth="605.0px" datasizeheight="58.0px" datasizewidthpx="605.0" datasizeheightpx="58.0" dataX="657.0" dataY="585.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_16_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_40" class="pie image firer click ie-background commentable non-processed" customid="Image_40"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="1222.0" dataY="616.0"   alt="image" systemName="./images/4b450a75-d62e-4ddb-93c1-44b28265cef0.svg" overlay="#A9A9A9">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" version="1" viewBox="0 0 24 24" width="24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z" fill="#A9A9A9" jimofill=" " /></g></svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_137" class="pie image firer ie-background commentable non-processed" customid="Image_136"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="673.0" dataY="614.0"   alt="image" systemName="./images/74730b78-3d49-4386-b311-f6826baae7fa.svg" overlay="#7D7D7D">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8 5v14l11-7z" fill="#7D7D7D" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="shapewrapper-s-Line_3" customid="Line 1" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="219.0px" datasizeheight="4.0px" datasizewidthpx="219.0044062036693" datasizeheightpx="4.0" dataX="681.0" dataY="602.0" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
                  <g>\
                      <g>\
                          <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 2.0 L 219.0044062036693 2.0"  >\
                          </path>\
                      </g>\
                  </g>\
                  <defs>\
                  </defs>\
              </svg>\
          </div>\
          <div id="shapewrapper-s-Line_4" customid="Line 2" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="363.0px" datasizeheight="4.0px" datasizewidthpx="363.0055096000612" datasizeheightpx="4.0" dataX="884.0" dataY="602.0" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
                  <g>\
                      <g>\
                          <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 2.0 L 363.0055096000612 2.0"  >\
                          </path>\
                      </g>\
                  </g>\
                  <defs>\
                  </defs>\
              </svg>\
          </div>\
          <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="81.4px" datasizeheight="19.0px" dataX="710.0" dataY="618.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_6_0">--:--:-- / --:--:--</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_45" class="pie image firer dragstart drag dragend ie-background commentable non-processed" customid="Image_45"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="1239.0" dataY="592.0"   alt="image" systemName="./images/8874552d-5a94-4123-8cf1-685ef01a1199.svg" overlay="#000000">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M18.41 16.59L13.82 12l4.59-4.59L17 6l-6 6 6 6zM6 6h2v12H6z" fill="#000000" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_42" class="pie image firer dragstart drag dragend ie-background commentable non-processed" customid="Image_42"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="664.0" dataY="592.0"   alt="image" systemName="./images/fedf25fd-dc44-49d6-94e1-ccd38167b27b.svg" overlay="#000000">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M5.59 7.41L10.18 12l-4.59 4.59L7 18l6-6-6-6zM16 6h2v12h-2z" fill="#000000" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="bottom video" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 6"   datasizewidth="605.0px" datasizeheight="58.0px" datasizewidthpx="605.0" datasizeheightpx="58.0" dataX="657.0" dataY="585.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_6_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_136" class="pie image firer ie-background commentable non-processed" customid="Image_136"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="672.0" dataY="614.0"   alt="image" systemName="./images/794b47d2-ef3a-4095-af84-4b5972bdee96.svg" overlay="#7D7D7D">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M8 5v14l11-7z" fill="#7D7D7D" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="219.0px" datasizeheight="4.0px" datasizewidthpx="219.0044062036693" datasizeheightpx="4.0" dataX="680.0" dataY="602.0" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                  <g>\
                      <g>\
                          <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 2.0 L 219.0044062036693 2.0"  >\
                          </path>\
                      </g>\
                  </g>\
                  <defs>\
                  </defs>\
              </svg>\
          </div>\
          <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="363.0px" datasizeheight="4.0px" datasizewidthpx="363.0055096000612" datasizeheightpx="4.0" dataX="883.0" dataY="602.0" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
                  <g>\
                      <g>\
                          <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 2.0 L 363.0055096000612 2.0"  >\
                          </path>\
                      </g>\
                  </g>\
                  <defs>\
                  </defs>\
              </svg>\
          </div>\
          <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="81.4px" datasizeheight="19.0px" dataX="709.0" dataY="618.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">--:--:-- / --:--:--</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_43" class="pie image firer ie-background commentable non-processed" customid="Image_43"   datasizewidth="26.0px" datasizeheight="26.0px" dataX="1222.0" dataY="614.0"   alt="image" systemName="./images/33388a55-9a56-45cf-8c44-abc7a4796212.svg" overlay="#7D7D7D">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" fill="#7D7D7D" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_79" class="pie image firer click ie-background commentable non-processed" customid="Image_79"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="1191.0" dataY="617.0"   alt="image" systemName="./images/9d42d69a-44f0-4ffd-9fab-149f3c65b830.svg" overlay="#7D7D7D">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M9.64 7.64c.23-.5.36-1.05.36-1.64 0-2.21-1.79-4-4-4S2 3.79 2 6s1.79 4 4 4c.59 0 1.14-.13 1.64-.36L10 12l-2.36 2.36C7.14 14.13 6.59 14 6 14c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4c0-.59-.13-1.14-.36-1.64L12 14l7 7h3v-1L9.64 7.64zM6 8c-1.1 0-2-.89-2-2s.9-2 2-2 2 .89 2 2-.9 2-2 2zm0 12c-1.1 0-2-.89-2-2s.9-2 2-2 2 .89 2 2-.9 2-2 2zm6-7.5c-.28 0-.5-.22-.5-.5s.22-.5.5-.5.5.22.5.5-.22.5-.5.5zM19 3l-6 6 2 2 7-7V3z" fill="#7D7D7D" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="top button" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Button_1" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="109.0px" datasizeheight="32.0px" dataX="1011.0" dataY="109.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_1_0">Gravar a tela</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Button_2" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="130.0px" datasizeheight="32.0px" dataX="1133.0" dataY="109.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_2_0">Gravar a c&acirc;mera</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Lista" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="380.0px" datasizeheight="733.0px" datasizewidthpx="380.0" datasizeheightpx="733.0400000000002" dataX="260.0" dataY="67.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_20" class="group firer ie-background commentable hidden non-processed" customid="Card" datasizewidth="0.0px" datasizeheight="61.0px" >\
          <div id="s-Rectangle_23" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 9"   datasizewidth="360.0px" datasizeheight="95.0px" datasizewidthpx="360.0" datasizeheightpx="95.0" dataX="270.0" dataY="544.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_23_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_19" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="145.1px" datasizeheight="19.0px" dataX="357.0" dataY="585.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_19_0">HE, SHE, IT (Pronouns)</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_17" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="145.1px" datasizeheight="19.0px" dataX="357.0" dataY="571.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_17_0">HE, SHE, IT (Pronouns)</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_18" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="60.6px" datasizeheight="19.0px" dataX="357.0" dataY="555.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_18_0">Grammar</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_24" class="pie rectangle autofit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="27.8px" datasizeheight="20.0px" datasizewidthpx="27.765625" datasizeheightpx="20.0" dataX="356.0" dataY="612.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_24_0">pdf</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_24" class="pie image firer click ie-background commentable non-processed" customid="Image_18"   datasizewidth="14.0px" datasizeheight="15.0px" dataX="604.0" dataY="551.0"   alt="image" systemName="./images/b1116e8e-6e71-4ea9-9277-7104ac2a8a6c.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>close-icon copy</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_24-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B2B2B2" id="s-Image_24-Components" transform="translate(-729.000000, -1389.000000)">\
              	            <g id="s-Image_24-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
              	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_24-Fill-1" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_84" class="pie image firer ie-background commentable non-processed" customid="Image_82"   datasizewidth="68.0px" datasizeheight="68.0px" dataX="281.0" dataY="560.0"   alt="image" systemName="./images/4c47c886-5a8a-45a5-b055-b0da184920c8.svg" overlay="#7D7D7D">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" fill="#7D7D7D" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_19" class="group firer ie-background commentable non-processed" customid="Card" datasizewidth="0.0px" datasizeheight="61.0px" >\
          <div id="s-Rectangle_20" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 9"   datasizewidth="360.0px" datasizeheight="95.0px" datasizewidthpx="360.0" datasizeheightpx="95.0" dataX="270.0" dataY="439.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_20_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_15" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="271.5px" datasizeheight="38.0px" dataX="357.0" dataY="466.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_15_0">HE, SHE, IT (Pronouns)</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="60.6px" datasizeheight="19.0px" dataX="357.0" dataY="450.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_16_0">Grammar</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_21" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="32.3px" datasizeheight="18.0px" datasizewidthpx="32.33" datasizeheightpx="18.0" dataX="356.0" dataY="505.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_21_0">pdf</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_23" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="14.0px" datasizeheight="15.0px" dataX="604.0" dataY="446.0"   alt="image" systemName="./images/9277531a-2538-49d7-a4aa-ae065985183c.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>close-icon copy</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_23-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B2B2B2" id="s-Image_23-Components" transform="translate(-729.000000, -1389.000000)">\
              	            <g id="s-Image_23-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
              	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_23-Fill-1" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="70.7px" datasizeheight="70.7px" dataX="277.0" dataY="452.3"   alt="image">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
            		<img src="./images/67eccd35-d746-4fd8-9a5d-c4a96deb6ee0.png" />\
            	</div>\
            </div>\
          </div>\
\
          <div id="s-Rectangle_22" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="360.0px" datasizeheight="95.0px" datasizewidthpx="360.0" datasizeheightpx="95.0" dataX="270.0" dataY="439.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_22_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_18" class="group firer ie-background commentable non-processed" customid="Card" datasizewidth="0.0px" datasizeheight="61.0px" >\
          <div id="s-Rectangle_13" class="pie rectangle manualfit firer pageload commentable non-processed" customid="Rectangle 9"   datasizewidth="360.0px" datasizeheight="95.0px" datasizewidthpx="360.0" datasizeheightpx="95.0" dataX="270.0" dataY="333.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_13_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_13" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="271.5px" datasizeheight="38.0px" dataX="357.0" dataY="360.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_13_0">Short explanation<br />5:36</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_14" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="102.2px" datasizeheight="19.0px" dataX="357.0" dataY="344.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_14_0">Tongue Twisters</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_14" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="49.3px" datasizeheight="18.0px" datasizewidthpx="49.33" datasizeheightpx="18.0" dataX="356.0" dataY="399.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_14_0">Video</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_22" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="14.0px" datasizeheight="15.0px" dataX="604.0" dataY="340.0"   alt="image" systemName="./images/27eead93-ddf6-4912-8679-875eb37862ad.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>close-icon copy</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_22-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B2B2B2" id="s-Image_22-Components" transform="translate(-729.000000, -1389.000000)">\
              	            <g id="s-Image_22-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
              	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_22-Fill-1" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_29" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="61.5px" datasizeheight="61.5px" dataX="282.0" dataY="346.5"   alt="image" systemName="./images/2c105e2a-5b7c-4bed-9ad6-6411eaa5a534.svg" overlay="#808080">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
              	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
              	    <title>Combined Shape</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_29-Page-1" stroke="none" stroke-width="1">\
              	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_29-Combined-Shape" style="fill:#808080 !important;" />\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_17" class="group firer ie-background commentable non-processed" customid="Card" datasizewidth="0.0px" datasizeheight="61.0px" >\
          <div id="s-Rectangle_11" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 9"   datasizewidth="360.0px" datasizeheight="95.0px" datasizewidthpx="360.0" datasizeheightpx="95.0" dataX="270.0" dataY="228.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_11_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_11" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="271.5px" datasizeheight="38.0px" dataX="357.0" dataY="255.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_11_0">Oral presentation instructions</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_12" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="144.1px" datasizeheight="19.0px" dataX="357.0" dataY="239.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_12_0">Oral Presentation.docx</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_12" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="36.2px" datasizeheight="18.0px" datasizewidthpx="36.19856770833343" datasizeheightpx="18.0" dataX="356.0" dataY="294.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_12_0">doc</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_21" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="14.0px" datasizeheight="15.0px" dataX="604.0" dataY="235.0"   alt="image" systemName="./images/1740f76b-c1b1-44c5-aff0-8c365ea3672c.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>close-icon copy</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_21-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B2B2B2" id="s-Image_21-Components" transform="translate(-729.000000, -1389.000000)">\
              	            <g id="s-Image_21-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
              	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_21-Fill-1" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_83" class="pie image firer ie-background commentable non-processed" customid="Image_82"   datasizewidth="68.0px" datasizeheight="68.0px" dataX="278.0" dataY="244.0"   alt="image" systemName="./images/e0e2150f-a69e-4628-a118-ec63eaa310dc.svg" overlay="#808080">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" fill="#808080" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Rectangle_15" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="71.2px" datasizeheight="18.0px" datasizewidthpx="71.19856770833337" datasizeheightpx="18.0" dataX="398.8" dataY="294.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_15_0">Av. oral</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Card" datasizewidth="0.0px" datasizeheight="61.0px" >\
          <div id="s-Rectangle_9" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 9"   datasizewidth="360.0px" datasizeheight="95.0px" datasizewidthpx="360.0" datasizeheightpx="95.0" dataX="270.0" dataY="122.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_9_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="271.5px" datasizeheight="57.0px" dataX="357.0" dataY="149.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">Short explanation<br />3:19</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="96.7px" datasizeheight="19.0px" dataX="357.0" dataY="133.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_1_0">Present Perfect</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="49.3px" datasizeheight="18.0px" datasizewidthpx="49.326660156249886" datasizeheightpx="18.000000000000057" dataX="356.0" dataY="188.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_8_0">Video</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_18" class="pie image firer ie-background commentable non-processed" customid="Image_18"   datasizewidth="14.0px" datasizeheight="15.0px" dataX="604.0" dataY="129.0"   alt="image" systemName="./images/50b98e0d-0ace-4ace-b57d-5d19c291fc4c.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>close-icon copy</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_18-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B2B2B2" id="s-Image_18-Components" transform="translate(-729.000000, -1389.000000)">\
              	            <g id="s-Image_18-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
              	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_18-Fill-1" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
\
          <div id="s-Image_26" class="pie image firer ie-background commentable non-processed" customid="Image_26"   datasizewidth="61.5px" datasizeheight="61.5px" dataX="282.0" dataY="135.5"   alt="image" systemName="./images/1f339aa4-8d32-43e7-a16d-4bf1e4f951b1.svg" overlay="#808080">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="57px" version="1.1" viewBox="0 0 57 57" width="57px">\
              	    <!-- Generator: Sketch 55.1 (78136) - https://sketchapp.com -->\
              	    <title>Combined Shape</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_26-Page-1" stroke="none" stroke-width="1">\
              	        <path d="M46.9324558,46.9498961 C51.857426,42.0257767 54.5692648,35.4782633 54.5682442,28.5133737 C54.5682442,14.1330394 42.8725245,2.43374687 28.496614,2.43374687 C14.1184916,2.43374687 2.42107075,14.1330394 2.42107075,28.5133737 C2.42107075,42.8892842 14.1184916,54.5848334 28.496614,54.5848334 C35.4609931,54.5848334 42.0083364,51.8735051 46.9324558,46.9498961 Z M48.6461991,8.36208716 C54.0285304,13.7442484 56.9921901,20.900726 56.9913396,28.5133737 C56.9913396,44.2208722 44.2087066,56.9999319 28.496614,56.9999319 C12.7835006,56.9999319 1.70149254e-05,44.2208722 1.70149254e-05,28.5133737 C1.70149254e-05,12.8000901 12.7835006,0.0166065672 28.496614,0.0166065672 C36.1082409,0.0166065672 43.2640379,2.98043642 48.6461991,8.36208716 Z M36.4362247,27.9682344 C36.7886898,28.2099412 37.0017915,28.5897419 37,29.0016456 C37,29.4069248 36.7922956,29.7882542 36.4362247,30.0352266 L25.1595027,37.7513291 C24.9209802,37.9166001 24.6390081,38 24.3606418,38 C24.1473598,38 23.936061,37.9539687 23.7426108,37.862076 C23.2853976,37.6441492 23,37.2031999 23,36.7196165 L23,21.2787488 C23,20.8002611 23.2853976,20.3576133 23.7426108,20.1396865 C24.1962181,19.9200611 24.745559,19.9625254 25.1595027,20.2451678 L36.4362247,27.9682344 Z" fill="#CBCBCB" fill-rule="nonzero" id="s-Image_26-Combined-Shape" style="fill:#808080 !important;" />\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="titulo" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="380.0px" datasizeheight="50.0px" datasizewidthpx="380.0" datasizeheightpx="50.0" dataX="260.0" dataY="67.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_2_0">Material</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image_1"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="598.0" dataY="80.0"   alt="image" systemName="./images/9ba55c43-38d1-4c22-b5ae-9e2e675f3485.svg" overlay="#FFFFFF">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z" fill="#FFFFFF" jimofill=" " /></svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Busca" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="247.0px" datasizeheight="347.0px" datasizewidthpx="247.00000000000023" datasizeheightpx="347.0400000000002" dataX="7.0" dataY="77.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Category_1" class="pie radiobuttonlist firer ie-background commentable non-processed" customid="Category"    datasizewidth="205.0px" datasizeheight="246.7px" dataX="34.0" dataY="160.0"  tabindex="-1">\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="scroll">\
              <div class="paddingLayer">\
                <table class="collapse" style="height: 100%; width: 100%;" summary="">\
                  <tbody>\
                    <tr>\
                      <td>\
                          <input type="radio" name="s-Category_1" checked="checked"  tabindex="-1" ></div>\
                          <span class="option">Todos</span>\
                      </td>\
                    </tr>\
                    <tr>\
                      <td>\
                          <input type="radio" name="s-Category_1"   tabindex="-1" ></div>\
                          <span class="option">Documento de texto</span>\
                      </td>\
                    </tr>\
                    <tr>\
                      <td>\
                          <input type="radio" name="s-Category_1"   tabindex="-1" ></div>\
                          <span class="option">Planilha</span>\
                      </td>\
                    </tr>\
                    <tr>\
                      <td>\
                          <input type="radio" name="s-Category_1"   tabindex="-1" ></div>\
                          <span class="option">pdf</span>\
                      </td>\
                    </tr>\
                    <tr>\
                      <td>\
                          <input type="radio" name="s-Category_1"   tabindex="-1" ></div>\
                          <span class="option">V&iacute;deo</span>\
                      </td>\
                    </tr>\
                    <tr>\
                      <td>\
                          <input type="radio" name="s-Category_1"   tabindex="-1" ></div>\
                          <span class="option">Link</span>\
                      </td>\
                    </tr>\
                  </tbody>\
                </table>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Search-input" class="group firer ie-background commentable non-processed" customid="Search-input" datasizewidth="347.0px" datasizeheight="46.0px" >\
          <div id="s-Input_search" class="pie text firer commentable non-processed" customid="Input_search"  datasizewidth="217.0px" datasizeheight="46.0px" dataX="22.0" dataY="94.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Procurar"/></div></div>  </div></div></div>\
\
          <div id="s-Image_37" class="pie image firer ie-background commentable non-processed" customid="Image_37"   datasizewidth="19.0px" datasizeheight="20.0px" dataX="212.0" dataY="106.0"   alt="image" systemName="./images/8b3398ac-7393-4252-8c77-8a91e073c0a7.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 19 20" width="19px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Icon</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_37-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B1B1B1" id="Header-#6" transform="translate(-1068.000000, -25.000000)">\
              	            <g id="s-Image_37-Search-" transform="translate(1068.000000, 17.000000)">\
              	                <path d="M12.939,16.271 C12.939,19.121 10.621,21.439 7.771,21.439 C4.921,21.439 2.584,19.121 2.584,16.271 C2.584,13.402 4.902,11.084 7.771,11.084 C10.621,11.084 12.939,13.421 12.939,16.271 L12.939,16.271 Z M14.174,20.66 C15.067,19.387 15.542,17.829 15.542,16.271 C15.542,11.977 12.065,8.5 7.771,8.5 C3.477,8.5 0,11.977 0,16.271 C0,20.565 3.477,24.042 7.771,24.042 C9.329,24.042 10.887,23.548 12.179,22.674 L17.005,27.5 L19,25.505 L14.174,20.66 Z" id="s-Image_37-Icon" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_12" class="group firer ie-background commentable hidden non-processed" customid="janela salvar video" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_10" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 10"   datasizewidth="389.0px" datasizeheight="267.0px" datasizewidthpx="388.99999999999966" datasizeheightpx="267.00000000000006" dataX="762.0" dataY="288.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_10_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="784.0" dataY="349.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="T&iacute;tulo do v&iacute;deo"/></div></div>  </div></div></div>\
        <div id="s-Input_2" class="pie textarea firer commentable non-processed" customid="Input_2"  datasizewidth="345.0px" datasizeheight="127.0px" dataX="784.0" dataY="407.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder="Coment&aacute;rios"></textarea></div></div></div>\
        <div id="s-Button_4" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="1061.0" dataY="304.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0">Salvar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph 5"   datasizewidth="165.0px" datasizeheight="22.0px" dataX="784.5" dataY="314.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Detalhes do v&iacute;deo</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="filtro turmas" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_22" class="group firer ie-background commentable non-processed" customid="Card turma 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_19" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 2"   datasizewidth="226.0px" datasizeheight="65.0px" datasizewidthpx="225.99999999999955" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="441.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_19_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_25" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="16.0px" datasizeheight="65.0px" datasizewidthpx="16.019157088121347" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="441.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_25_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_32" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="44.4px" datasizeheight="19.0px" dataX="52.0" dataY="454.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_32_0">1&deg; ADS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_33" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="32.2px" datasizeheight="19.0px" dataX="52.0" dataY="472.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_33_0">ING I</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_30" class="group firer ie-background commentable non-processed" customid="Card turma3" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_40" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 2"   datasizewidth="226.0px" datasizeheight="65.0px" datasizewidthpx="225.99999999999955" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="505.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_40_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_41" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="16.0px" datasizeheight="65.0px" datasizewidthpx="16.019157088121347" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="505.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_41_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_38" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="44.4px" datasizeheight="19.0px" dataX="52.0" dataY="518.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_38_0">3&deg; ADS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_39" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="40.0px" datasizeheight="19.0px" dataX="52.0" dataY="536.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_39_0">ING III</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_31" class="group firer ie-background commentable non-processed" customid="Card turma4" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_42" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 2"   datasizewidth="226.0px" datasizeheight="65.0px" datasizewidthpx="225.99999999999955" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="569.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_42_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_43" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="16.0px" datasizeheight="65.0px" datasizewidthpx="16.019157088121347" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="569.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_43_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_40" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="44.4px" datasizeheight="19.0px" dataX="52.0" dataY="582.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_40_0">4&deg; ADS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_41" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="40.5px" datasizeheight="19.0px" dataX="52.0" dataY="600.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_41_0">ING IV</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_32" class="group firer ie-background commentable non-processed" customid="Card turma5" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_44" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 2"   datasizewidth="226.0px" datasizeheight="65.0px" datasizewidthpx="225.99999999999955" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="633.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_44_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_45" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="16.0px" datasizeheight="65.0px" datasizewidthpx="16.019157088121347" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="633.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_45_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_42" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="44.4px" datasizeheight="19.0px" dataX="52.0" dataY="646.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_42_0">5&deg; ADS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_43" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="36.6px" datasizeheight="19.0px" dataX="52.0" dataY="664.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_43_0">ING V</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_33" class="group firer ie-background commentable non-processed" customid="Card turma6" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_46" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 2"   datasizewidth="226.0px" datasizeheight="65.0px" datasizewidthpx="225.99999999999955" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="697.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_46_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_47" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="16.0px" datasizeheight="65.0px" datasizewidthpx="16.019157088121347" datasizeheightpx="65.00000000000003" dataX="27.0" dataY="697.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_47_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_44" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="44.4px" datasizeheight="19.0px" dataX="52.0" dataY="710.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_44_0">6&deg; ADS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_45" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 4"   datasizewidth="40.5px" datasizeheight="19.0px" dataX="52.0" dataY="728.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_45_0">ING VI</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Top Menu" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="top"   datasizewidth="1280.0px" datasizeheight="67.0px" datasizewidthpx="1280.0" datasizeheightpx="66.99999999999952" dataX="-0.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Menu" datasizewidth="1024.0px" datasizeheight="150.0px" >\
          <div id="s-Text_4" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Text_4"   datasizewidth="278.0px" datasizeheight="67.0px" dataX="252.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_4_0">CONTE&Uacute;DO PROGRAM&Aacute;TICO</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_2" class="pie richtext manualfit firer mousedown click commentable non-processed" customid="Text_2"   datasizewidth="128.0px" datasizeheight="67.0px" dataX="124.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_2_0">BIBLIOTECA</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_1" class="pie richtext manualfit firer click ie-background commentable non-processed" customid="Text_1"   datasizewidth="124.0px" datasizeheight="67.0px" dataX="0.0" dataY="0.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_1_0">HOME</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_14" class="group firer ie-background commentable hidden non-processed" customid="upload arquivo" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_18" class="pie rectangle manualfit firer pageload commentable non-processed" customid="Rectangle 18"   datasizewidth="1280.3px" datasizeheight="733.4px" datasizewidthpx="1280.2500000000002" datasizeheightpx="733.3981150602285" dataX="-0.3" dataY="67.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_18_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_15" class="group firer ie-background commentable non-processed" customid="centro" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_17" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 17"   datasizewidth="428.0px" datasizeheight="429.0px" datasizewidthpx="428.00000000000034" datasizeheightpx="429.00000000000045" dataX="426.0" dataY="219.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_17_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 7"   datasizewidth="137.7px" datasizeheight="21.0px" dataX="462.0" dataY="240.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_7_0">Upload de arquivo</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 8"   datasizewidth="50.5px" datasizeheight="21.0px" dataX="462.0" dataY="377.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_8_0">T&iacute;tulo: </span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="oculto-nome-do-arquivo"   datasizewidth="0.0px" datasizeheight="42.0px" dataX="513.0" dataY="377.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_9_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Input_1" class="pie file firer change commentable non-processed" customid="Input"  datasizewidth="353.0px" datasizeheight="29.0px" dataX="461.4" dataY="290.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class ="paddingLayer"><div class="content"><div class="valign"><input type="text"   readonly="readonly" tabindex="-1" /></div></div></div></div><div class="icon" >&nbsp;</div><input class="file-input firer "  type="file" size="1"  tabindex="-1" /></div>\
          <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="353.0px" datasizeheight="35.6px" dataX="462.0" dataY="414.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Autor"/></div></div>  </div></div></div>\
          <div id="s-Input_5" class="pie textarea firer commentable non-processed" customid="Input_2"  datasizewidth="354.0px" datasizeheight="103.0px" dataX="462.0" dataY="467.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder="Coment&aacute;rio"></textarea></div></div></div>\
          <div id="s-Input_6" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="354.0px" datasizeheight="35.6px" dataX="462.0" dataY="587.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Tags"/></div></div>  </div></div></div>\
          <div id="s-Category_2" class="pie dropdown firer commentable non-processed" customid="Category"    datasizewidth="214.0px" datasizeheight="29.0px" dataX="530.9" dataY="333.0"  tabindex="-1"><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">1&deg; ADS</div></div></div></div></div><select id="s-Category_2-options" class="s-8e663f7c-7e1d-430e-a531-c3d3c8975e2d dropdown-options" ><option selected="selected" class="option">1&deg; ADS</option>\
          <option  class="option">3&deg; ADS</option>\
          <option  class="option">4&deg; ADS</option>\
          <option  class="option">5&deg; ADS</option>\
          <option  class="option">6&deg; ADS</option></select></div>\
\
          <div id="s-Image_20" class="pie image firer click ie-background commentable non-processed" customid="Image_18"   datasizewidth="17.0px" datasizeheight="17.0px" dataX="830.0" dataY="226.5"   alt="image" systemName="./images/44dec5a7-9f99-4e9c-a3bf-c7bfd5f6a7fe.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>close-icon copy</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_20-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#B2B2B2" id="s-Image_20-Components" transform="translate(-729.000000, -1389.000000)">\
              	            <g id="s-Image_20-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
              	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_20-Fill-1" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Button_5" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="748.0" dataY="236.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Button_5_0">Salvar</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 8"   datasizewidth="53.2px" datasizeheight="21.0px" dataX="462.0" dataY="337.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_10_0">Turma:</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable hidden non-processed" customid="Document Overflow" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="1280.0px" datasizeheight="733.0px" datasizewidthpx="1280.0" datasizeheightpx="733.0400000000002" dataX="0.0" dataY="67.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Browser_1" class="pie url firer ie-background commentable non-processed" datasizewidth="1256.0px" datasizeheight="707.0px" dataX="12.0" dataY="93.0" >\
          <div class="commentpanel hidden"></div>\
          <div class="borderLayer">\
          	<object width="100%" height="100%">\
          	  <param name="src" value="./external/documents/23517461-bf91-4efc-9eb5-258ccf15a7a8.pdf#toolbar=0&amp;navpanes=0"></param>\
          	  <embed width="100%" height="100%" src="./external/documents/23517461-bf91-4efc-9eb5-258ccf15a7a8.pdf#toolbar=0&amp;navpanes=0" type="application/pdf"></embed>\
          	</object>\
          </div>\
        </div>\
\
        <div id="s-Image_19" class="pie image firer click ie-background commentable non-processed" customid="Image_18"   datasizewidth="20.0px" datasizeheight="20.0px" dataX="1246.0" dataY="71.0"   alt="image" systemName="./images/d6a492af-1560-4fb4-b349-586654b9069c.svg" overlay="#434343">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 20 20" width="20px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>close-icon copy</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_19-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#B2B2B2" id="s-Image_19-Components" transform="translate(-729.000000, -1389.000000)">\
            	            <g id="s-Image_19-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
            	                <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_19-Fill-1" style="fill:#434343 !important;" />\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;